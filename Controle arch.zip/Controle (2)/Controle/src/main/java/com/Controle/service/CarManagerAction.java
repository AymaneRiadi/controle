package com.Controle.service;

import com.Controle.dao.entities.Car;
import com.Controle.dao.repositories.CarRepository;
import com.Controle.service.dtos.CarDTO;
import com.Controle.service.dtos.CarDTOInput;
import com.Controle.service.mappers.CarMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class CarManagerAction implements CarManager{

    @Autowired
    private CarRepository carRepository;
    @Autowired
    private CarMapper carMapper;
    @Override
    public CarDTO getCarByModel(String model) {
        return carMapper.fromCarToCarDto(carRepository.findByModel(model));
    }

    @Override
    public CarDTO getCarByModelAndPrice(String model, Float price) {
        return null;
    }

    @Override
    public CarDTOInput saveCar(CarDTOInput carDTOInput) {
        return null;
    }

    @Override
    public CarDTOInput deleteCar(Float id) {
        return null;
    }
}
