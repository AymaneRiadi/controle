package com.Controle.service.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CarDTOInput {

    private Long id;
    private String model;
    private String color;
    private String matricul;
    private Float price;
}
