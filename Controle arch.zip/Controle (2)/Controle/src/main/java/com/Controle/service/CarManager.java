package com.Controle.service;

import com.Controle.service.dtos.CarDTO;
import com.Controle.service.dtos.CarDTOInput;

public interface CarManager {
    public CarDTO getCarByModel(String model);
    public CarDTO getCarByModelAndPrice(String model, Float price);
    public CarDTOInput saveCar(CarDTOInput carDTOInput);
    public CarDTOInput deleteCar(Float id);

}
