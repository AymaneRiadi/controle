package com.Controle.service.mappers;

import com.Controle.dao.entities.Car;
import com.Controle.service.dtos.CarDTO;
import com.Controle.service.dtos.CarDTOInput;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class CarMapper {
    private ModelMapper modelMapper = new ModelMapper();

    public Car fromCarDtoToCar(CarDTO carDTO) {
        return this.modelMapper.map(carDTO, Car.class);
    }

    public CarDTO fromCarToCarDto(Car car) {
        return this.modelMapper.map(car, CarDTO.class);
    }

    public CarDTOInput fromCarDtoToCarDTOInput(CarDTO carDTO) {
        return this.modelMapper.map(carDTO, CarDTOInput.class);
    }

    public Car fromCarDtoInputToCar(CarDTOInput carDTOInput) {
        return this.modelMapper.map(carDTOInput, Car.class);
    }
}
